git config user.name "John Doe" 
git config user.email "John Doe" 